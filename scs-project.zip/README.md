# scs-proj


Start benchmarking script using `python3 benchmark.py --gui`
